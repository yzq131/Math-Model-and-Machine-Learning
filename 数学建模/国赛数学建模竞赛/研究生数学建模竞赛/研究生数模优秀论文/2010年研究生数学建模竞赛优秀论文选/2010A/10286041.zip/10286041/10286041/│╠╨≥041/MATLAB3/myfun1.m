function f=myfun1(x,H)
f=1/2*x'*H*x-sum(x);