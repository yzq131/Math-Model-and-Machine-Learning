function f=myfun2(x,H)
f=sqrt(x'*H*x)-sum(x);