function f=myfun3(x,H,L)
f=1/2*x'*H*x-sum(x)+x'*L*x;